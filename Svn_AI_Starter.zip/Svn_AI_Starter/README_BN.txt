Svn.AI — Starter Demo

এটি Svn.AI-এর প্রথম বিনামূল্যের UI prototype। এখনো এটি পূর্ণ AI নয়:
- Chat screen ও বাংলা demo replies আছে।
- সমর্থিত ব্রাউজারে বাংলা speech-to-text চেষ্টা করে।
- চাইলে browser speech synthesis দিয়ে উত্তর পড়ে শোনায় (এখন ডিফল্টে বন্ধ)।
- কোনো API key বা টাকা লাগে না।

চালানোর নিয়ম:
1) ZIP ফাইল Extract করুন।
2) index.html ফাইল Chrome-এ খুলুন।
3) মাইক্রোফোন ব্যবহার করতে চাইলে সাইট/ফাইলের microphone permission দিন।
4) Voice reply চালু করতে Chrome DevTools Console-এ লিখতে হয়:
   localStorage.setItem("svn_voice","on")
   (এটি ঐচ্ছিক; পরের সংস্করণে Settings বোতাম যোগ হবে।)

গুরুত্বপূর্ণ:
- কিছু browser-এ file:// থেকে microphone বা PWA কাজ নাও করতে পারে।
- PWA install/offline চালাতে HTTPS hosting বা localhost দরকার।
- এই demo-তে কথোপকথন server-এ পাঠানো হয় না।
- আসল AI যুক্ত করার আগে backend server লাগবে; API key কখনো app-এর HTML/JS-এ রাখবেন না।
- WhatsApp integration-এর জন্য WhatsApp Business Platform/API ও আলাদা অনুমোদন/খরচ হতে পারে।
